# The MIT License.
# Copyright (C) 2017 The Future Shell , DeathSec.
#
# Indents Python source files to PEP8 Coding Style.
# Depends on autopep8

autopep8 -i bin/instagram-py \
	    InstagramPy/*py

echo "Converted Source files to PEP8 Style!"
echo "exiting... "

