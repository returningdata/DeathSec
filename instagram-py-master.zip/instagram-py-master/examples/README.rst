==================================
 Instagram-Py Scripting Examples
==================================

------------------------
 Multi Username attack 
------------------------

**filename:** multi_attack.py

::

 $ # After installation of instagram-py 2.0.0
 $ # Modify multi_attack.py to your victims
 $ chmod +x multi_attack.py
 $ ./multi_attack.py


