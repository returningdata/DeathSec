============================
ChangeLog for Instagram-Py 
============================

Holds the History of releases and changes made for the software.

version 2.0.1
        * Fixes JSON Decoding error from instagram api response

version 2.0.0 ( 2017.11.19 )
	* **New Feature:** Instagram-Py Scripting
	* **New Feature:** Instagram-Py Configuration Creator
	* **New Feature:** Instagram-Py Dumps ( Holds Successfully Cracked Account Passwords)
	* **New Feature:** Complete Attack Customization
	* lightly redesigned the cli

version 1.3.3 ( Stable )
	* killed some bugs
	* error handling added
	* removed flush and print output
	* new easy to use API implemented
	* making random device id for new process only
	* verbose added for better debuging
	* refactored the code base

version 0.3.2
	* fixed json decoding type error
	* support for python 3.4 , 3.5
	* added pip support

version 0.3.1
	* duplicate of v0.2.1 for a mistake in pypi

version 0.2.1 
	* fixed never resume attack bug
	* fixed corrupted savefile bug

version 0.1.1
	* fixed left out password on ip change
	* fixed corrupted buffer on password tries

version 0.0.1 (2017.09.08) 
	* basic features added
